import { useEffect, useState, type CSSProperties } from 'react';
import { Link, Route, Switch } from 'wouter';
import { ArrowDownRight, ArrowLeft, ArrowRight, Check, Copy, Hexagon } from 'lucide-react';

type Product = {
  name: string;
  route: string;
  category: string;
  description: string;
  detail: string;
  price?: string;
  stock?: number;
  art: string;
  ink: string;
  code: string;
};

const products: Product[] = [
  {
    name: 'Fatality.win',
    route: '/fatality-win',
    category: 'Competitive · Access',
    description: 'A direct route into a focused CS2 community.',
    detail: 'A CS2 community access listing for players who value a tighter signal-to-noise ratio. Review the demo details, then contact the seller about availability.',
    price: '$45.00',
    stock: 6,
    art: '#13232b',
    ink: '#8fcae1',
    code: 'FL / 001',
  },
  {
    name: 'Primordial.dev',
    route: '/primordial-dev',
    category: 'Developer · Access',
    description: 'A developer-minded corner of the CS2 community.',
    detail: 'A listing for a niche, technically minded CS2 community. The information and availability on this page are demo values for the storefront preview.',
    price: '$35.00',
    stock: 8,
    art: '#281d14',
    ink: '#f09b44',
    code: 'PD / 002',
  },
  {
    name: 'Monolith.club',
    route: '/monolith-club',
    category: 'Members · Access',
    description: 'A smaller CS2 community for people who prefer the uncommon.',
    detail: 'An access listing for a private-feeling CS2 community. Browse the preview and reach out to discuss the listing; no purchase is processed here.',
    price: '$25.00',
    stock: 12,
    art: '#19212a',
    ink: '#c7d1d3',
    code: 'MC / 003',
  },
  {
    name: 'Gamesense.win',
    route: '/gamesense-win',
    category: 'Community · Contact',
    description: 'A seller-mediated route. Start with a direct conversation.',
    detail: 'Gamesense.win is available by contacting the seller on Discord. There is no price or stock count displayed here; ask the seller for current details.',
    art: '#261d13',
    ink: '#f09b44',
    code: 'GS / 004',
  },
];

function Brand() {
  return (
    <Link href="/" className="brand" aria-label="Rift Ledger home" data-testid="link-brand-home">
      <span className="brand-mark"><Hexagon strokeWidth={2.4} /></span>
      <span>RIFT LEDGER</span>
    </Link>
  );
}

function Header() {
  return (
    <header className="site-header">
      <Brand />
      <nav className="header-nav" aria-label="Main navigation">
        <Link href="/" data-testid="link-nav-catalogue">Catalogue</Link>
        <a href="/#how-it-works" data-testid="link-nav-about">How it works</a>
      </nav>
      <div className="header-meta"><span className="live-dot" /> Independent listings</div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <span>Independent CS2 listings · Not affiliated with Valve</span>
      <div className="footer-links">
        <Link href="/" data-testid="link-footer-catalogue">Catalogue</Link>
        <a href="/#how-it-works" data-testid="link-footer-notes">Preview notes</a>
      </div>
      <span>Built for the curious</span>
    </footer>
  );
}

function Artwork({ product, detail = false }: { product: Product; detail?: boolean }) {
  const style = { '--art-bg': product.art, '--art-ink': product.ink } as CSSProperties;
  return (
    <div className={detail ? 'detail-art' : 'product-art'} style={style} aria-label={`${product.name} abstract artwork`}>
      <span className="art-stamp">RIFT / ACCESS</span>
      <span className="art-shape" />
      <span className="art-number" aria-hidden="true">{product.code.slice(0, 2)}</span>
      <span className="art-code">{product.code}</span>
    </div>
  );
}

function ProductCard({ product, index }: { product: Product; index: number }) {
  return (
    <article className="product-card" data-testid={`card-product-${product.route.slice(1)}`}>
      <Link href={product.route} aria-label={`View ${product.name} details`}>
        <Artwork product={product} />
      </Link>
      <div className="product-info">
        <div className="product-topline">
          <Link href={product.route} className="product-name" data-testid={`link-product-${index}`}>{product.name}</Link>
          <span className="product-category">{product.category}</span>
        </div>
        <p className="product-desc">{product.description}</p>
        <div className="product-footer">
          <div>
            {product.price ? <div className="price">{product.price}</div> : <div className="price" style={{ fontSize: 13 }}>Contact seller</div>}
            <div className="stock">{product.stock ? `${product.stock} available · demo value` : 'Seller-mediated'}</div>
          </div>
          <Link href={product.route} className="card-link" data-testid={`link-view-${index}`}>
            View listing <ArrowRight />
          </Link>
        </div>
      </div>
    </article>
  );
}

function Home() {
  return (
    <div className="site-shell">
      <Header />
      <main className="main-wrap">
        <section className="hero">
          <div>
            <div className="eyebrow">Counter-Strike 2 / Community access</div>
            <h1>Find your<br /><span>CS2 circle.</span></h1>
            <p className="hero-copy">An independent index of CS2 gaming communities. Compare the listings and open each page for details.</p>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <span className="orbit" />
            <span className="hero-emblem"><Hexagon strokeWidth={1.2} /></span>
            <span className="orbit-tag top">R / L—04 : OPEN INDEX</span>
            <span className="orbit-tag bottom">ACCESS, WITHOUT THE STATIC</span>
          </div>
          <span className="hero-index">FIELD NOTES / 001—004</span>
        </section>
        <div className="ticker">
          <div className="ticker-left"><span className="live-dot" /><strong>Four CS2 listings. One clear starting point.</strong></div>
          <div className="ticker-right"><span>Independent communities</span><span>Updated as listed</span><ArrowDownRight size={14} /></div>
        </div>
        <section className="catalogue" id="catalogue">
          <div className="section-heading">
            <div><div className="eyebrow">The current index</div><h2>Open listings</h2></div>
            <p>Explore the details before you reach out. Three prices and stock counts are demo values, not live inventory.</p>
          </div>
          <div className="products-grid">
            {products.map((product, index) => <ProductCard key={product.route} product={product} index={index} />)}
          </div>
          <div className="demo-note">DEMO VALUES: Fatality.win $45.00 / 6 available · Primordial.dev $35.00 / 8 available · Monolith.club $25.00 / 12 available</div>
        </section>
      </main>
      <section className="trust-strip" id="how-it-works">
        <div className="trust-inner">
          <div className="trust-intro">A little clarity goes a long way</div>
          <div className="trust-item"><strong>Read first</strong><span>Each listing has its own detail page and contact path.</span></div>
          <div className="trust-item"><strong>Preview, not checkout</strong><span>This storefront does not take payment or place orders.</span></div>
          <div className="trust-item"><strong>Seller sets the terms</strong><span>Confirm details directly before making any decision.</span></div>
        </div>
      </section>
      <Footer />
    </div>
  );
}

function ProductDetail({ product }: { product: Product }) {
  const [notice, setNotice] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!notice) return undefined;
    const timer = window.setTimeout(() => setNotice(false), 5200);
    return () => window.clearTimeout(timer);
  }, [notice]);

  async function copyHandle() {
    try {
      await navigator.clipboard.writeText('qwfereqreqw');
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2400);
    } catch {
      setCopied(false);
      const selection = window.getSelection();
      const handle = document.getElementById('seller-handle');
      if (selection && handle) {
        const range = document.createRange();
        range.selectNodeContents(handle);
        selection.removeAllRanges();
        selection.addRange(range);
      }
    }
  }

  return (
    <div className="site-shell">
      <Header />
      <main className="detail-wrap">
        <div className="breadcrumb">
          <Link href="/" data-testid="link-back-catalogue">Catalogue</Link><ArrowRight /><span>{product.name}</span>
        </div>
        <div className="detail-layout">
          <Artwork product={product} detail />
          <section className="detail-content">
            <div className="eyebrow">{product.category}</div>
            <h1>{product.name}</h1>
            <p className="detail-intro">{product.detail}</p>
            <div className="detail-badges">
              <span className="pill">Independent listing</span>
              <span className="pill">{product.price ? 'Preview values' : 'Contact seller'}</span>
            </div>
            {product.price ? (
              <>
                <div className="price-panel">
                  <div><div className="price-caption">Listing price · demo value</div><div className="detail-price">{product.price}</div></div>
                  <div className="availability"><strong>{product.stock} available</strong><span>Demo stock count</span></div>
                </div>
                <div className="preview-action">
                  <button className="primary-action" type="button" onClick={() => setNotice(true)} data-testid="button-preview-purchase">
                    <span>Continue to seller preview</span><ArrowRight />
                  </button>
                  <div className="preview-disclaimer">Preview only. No order or payment is placed here. Confirm current availability and terms with the seller before proceeding.</div>
                </div>
              </>
            ) : (
              <div className="contact-box">
                <div className="mono-label">Direct seller contact</div>
                <h2>Start on Discord.</h2>
                <p>Ask the seller about access and current details. Rift Ledger does not host a Discord profile link for this listing.</p>
                <div className="handle-copy">
                  <div className="handle-value" id="seller-handle" data-testid="text-seller-handle">qwfereqreqw</div>
                  <button className="copy-button" type="button" onClick={copyHandle} aria-label="Copy seller Discord handle" data-testid="button-copy-handle">
                    {copied ? <Check /> : <Copy />}{copied ? 'Copied' : 'Copy handle'}
                  </button>
                </div>
                <div className="copy-feedback" aria-live="polite">{copied ? 'Handle copied to clipboard.' : 'Discord handle · qwfereqreqw'}</div>
              </div>
            )}
            <div className="detail-specs">
              <h2>Listing notes</h2>
              <div className="spec-row"><span>Access type</span><span>Community listing</span></div>
              <div className="spec-row"><span>Purchase status</span><span>{product.price ? 'Preview only' : 'Contact seller'}</span></div>
              <div className="spec-row"><span>Availability</span><span>{product.stock ? `${product.stock} · demo value` : 'Ask seller'}</span></div>
            </div>
          </section>
        </div>
        <div className="detail-bottom">
          <Link href="/" data-testid="link-return-catalogue"><ArrowLeft /> Back to all listings</Link>
          <span className="mono-label">RIFT LEDGER / {product.code}</span>
        </div>
      </main>
      <Footer />
      {notice && (
        <div className="notice" role="status" data-testid="status-preview-notice">
          <strong>Storefront preview only</strong>
          <p>No order was created and no payment was taken. Contact the seller to confirm the listing and terms.</p>
        </div>
      )}
    </div>
  );
}

function NotFound() {
  return (
    <div className="site-shell">
      <Header />
      <main className="main-wrap not-found">
        <h1>Not in the ledger.</h1>
        <Link href="/" data-testid="link-not-found-home">Return to catalogue</Link>
      </main>
      <Footer />
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      {products.map((product) => (
        <Route key={product.route} path={product.route}>
          <ProductDetail product={product} />
        </Route>
      ))}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return <Router />;
}

export default App;
